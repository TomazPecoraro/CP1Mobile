package com.example.adega

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import androidx.activity.ComponentActivity
import androidx.core.widget.addTextChangedListener

class CachacaListActivity : ComponentActivity() {

    private val cachacas = arrayOf("Cachaça 51", "Cachaça Ypióca", "Cachaça Velho Barreiro")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cachaca_list)

        val backButton: ImageButton = findViewById(R.id.backButton)
        val searchField: EditText = findViewById(R.id.searchField)
        val listView: ListView = findViewById(R.id.cachacaListView)

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, cachacas)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val intent = Intent(this, CachacaDetailActivity::class.java)
            intent.putExtra("cachacaName", cachacas[position])
            startActivity(intent)
        }

        backButton.setOnClickListener {
            finish() // Volta para a tela anterior
        }

        searchField.addTextChangedListener { text ->
            adapter.filter.filter(text)
        }
    }
}
