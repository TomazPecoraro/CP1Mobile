package com.example.adega

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity

class CachacaDetailActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cachaca_detail)

        val backButton: ImageButton = findViewById(R.id.backButton)
        val cachacaNameTextView: TextView = findViewById(R.id.cachacaName)
        val cachacaDetailsTextView: TextView = findViewById(R.id.cachacaDetails)
        val cachacaImageView: ImageView = findViewById(R.id.cachacaImage)

        val cachacaName = intent.getStringExtra("cachacaName")

        cachacaNameTextView.text = cachacaName
        cachacaDetailsTextView.text = getCachacaDetails(cachacaName)

        // Define a imagem com base no nome da cachaça
        val imageResId = when (cachacaName) {
            "Cachaça 51" -> R.drawable.cachaca51
            "Cachaça Ypióca" -> R.drawable.ypioca
            "Cachaça Velho Barreiro" -> R.drawable.velhobarreiro
            else -> R.drawable.transferir// Imagem padrão, se necessário
        }

        cachacaImageView.setImageResource(imageResId)

        backButton.setOnClickListener {
            finish() // Volta para a tela anterior
        }
    }

    private fun getCachacaDetails(name: String?): String {
        return when (name) {
            "Cachaça 51" -> "Detalhes sobre a Cachaça 51."
            "Cachaça Ypióca" -> "Detalhes sobre a Cachaça Ypióca."
            "Cachaça Velho Barreiro" -> "Detalhes sobre a Cachaça Velho Barreiro."
            else -> "Detalhes não disponíveis."
        }
    }
}
