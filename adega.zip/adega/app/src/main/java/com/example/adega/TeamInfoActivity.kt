package com.example.adega

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TeamInfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_team_info)

        // Configurar imagens dos integrantes
        val member1Image: ImageView = findViewById(R.id.member1Image)
        val member2Image: ImageView = findViewById(R.id.member2Image)
        val member3Image: ImageView = findViewById(R.id.member3Image)

        member1Image.setImageResource(R.drawable.member1)
        member2Image.setImageResource(R.drawable.member2)
        member3Image.setImageResource(R.drawable.member3)

        // Configurar o botão de voltar
        val backButton: ImageButton = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            finish() // Voltar para a tela anterior
        }

        // Configurar o TextView para mostrar informações dos integrantes
        val membername1: TextView = findViewById(R.id.memberName1)
        membername1.text = """
            - Pedro Carvalho Pacheco -
             RM98043
        """.trimIndent()

        val membername2: TextView = findViewById(R.id.memberName2)
        membername2.text = """
            
            - Luiz Felipe Camargo Prendin - RM552475
        """.trimIndent()

        val membername3: TextView = findViewById(R.id.memberName3)
        membername3.text = """
            - Tomaz de Oliveira Pecoraro - RM98499
        """.trimIndent()
    }
}
