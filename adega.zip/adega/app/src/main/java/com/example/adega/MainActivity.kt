package com.example.adega

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val wineButton: Button = findViewById(R.id.wineButton)
        val cachacaButton: Button = findViewById(R.id.cachacaButton)
        val teamButton: Button = findViewById(R.id.teamButton)

        wineButton.setOnClickListener {
            startActivity(Intent(this, WineListActivity::class.java))
        }

        cachacaButton.setOnClickListener {
            startActivity(Intent(this, CachacaListActivity::class.java))
        }

        teamButton.setOnClickListener {
            startActivity(Intent(this, TeamInfoActivity::class.java))
        }
    }
}
