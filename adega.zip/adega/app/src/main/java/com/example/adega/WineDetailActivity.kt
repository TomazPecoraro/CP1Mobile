package com.example.adega

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity

class WineDetailActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wine_detail)

        val backButton: ImageButton = findViewById(R.id.backButton)
        val wineNameTextView: TextView = findViewById(R.id.wineName)
        val wineDetailsTextView: TextView = findViewById(R.id.wineDetails)
        val wineImageView: ImageView = findViewById(R.id.wineImage)

        val wineName = intent.getStringExtra("wineName")

        wineNameTextView.text = wineName
        wineDetailsTextView.text = getWineDetails(wineName)

        // Define a imagem com base no nome do vinho
        val imageResId = when (wineName) {
            "Chardonnay" -> R.drawable.chardonnay
            "Merlot" -> R.drawable.merlot
            "Cabernet Sauvignon" -> R.drawable.cabernet
            "Pinot Noir" -> R.drawable.pinot
            else -> R.drawable.wine // Imagem padrão, se necessário
        }

        wineImageView.setImageResource(imageResId)

        backButton.setOnClickListener {
            finish() // Volta para a tela anterior
        }
    }

    private fun getWineDetails(name: String?): String {
        return when (name) {
            "Chardonnay" -> "Detalhes sobre o Chardonnay."
            "Merlot" -> "Detalhes sobre o Merlot."
            "Cabernet Sauvignon" -> "Detalhes sobre o Cabernet Sauvignon."
            "Pinot Noir" -> "Detalhes sobre o Pinot Noir."
            else -> "Detalhes não disponíveis."
        }
    }
}
